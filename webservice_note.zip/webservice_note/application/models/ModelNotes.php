<?php
class ModelNotes extends CI_Model{


public function tampilAll($table,$where){
	// $d=$this->db->get($table)->order_by('id', 'ASC');
	// //$d=$this->db->order_by('kata', 'ASC');

	// return $d;
	  // $this->db->order_by('kata', 'ASC');
   //  $query = $this->db->get($table);
   //  return $query;
return $this->db->get_where($table,$where);
}
public function update($where,$data,$table){
	$this->db->where($where);
	$this->db->update($table,$data);
}
public function delete($id){
	//return $this->db->get('tb_info_isyarat');
	$this->db->where('id',$id);
	$this->db->delete('tb_notes');
}
public function cek($table,$where){
	return $this->db->get_where($table,$where);
}

}